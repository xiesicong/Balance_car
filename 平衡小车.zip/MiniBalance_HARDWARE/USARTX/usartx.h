#ifndef __USRAT3_H
#define __USRAT3_H 
#include "sys.h"	  	
  /**************************************************************************
���ߣ�ƽ��С��֮��
�ҵ��Ա�С�꣺http://shop114407458.taobao.com/
**************************************************************************/
extern u8 Usart2_Receive;
void uart2_init(u32 bound);
void USART2_IRQHandler(void);
#endif

